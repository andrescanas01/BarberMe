from kivy.uix.screenmanager import Screen

class IsAShopScreen(Screen):
    pass

