from kivy.uix.screenmanager import Screen

class CreateShopAccountScreen(Screen):
    pass

