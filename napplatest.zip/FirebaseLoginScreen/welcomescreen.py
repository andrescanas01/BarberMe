from kivy.uix.screenmanager import Screen

class WelcomeScreen(Screen):
    pass

